"""One-shot guarded authorized control adoption; no functional source changes."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import re

ROOT = Path.cwd()
OUT = ROOT / '.runtime/implementation-aud15-20261015/control'
BACKUP = OUT / 'backup-before-adoption'
manifest = json.loads((BACKUP / 'manifest.json').read_text())['files']
for rel, meta in manifest.items():
    assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == meta['sha256'], f'baseline changed: {rel}'

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

now = datetime.now(timezone.utc)
def ts(n=0):
    return (now + timedelta(microseconds=n)).isoformat().replace('+00:00', 'Z')

spec_ref = 'docs/backlog-auditoria-2026-10-15.md'
spec = (ROOT / spec_ref).read_text()
rows = {}
for line in spec.splitlines():
    if line.startswith('| AUD15-T'):
        cols = [v.strip() for v in line.strip('|').split('|')]
        rows[cols[0]] = cols
sections = list(re.finditer(r'^### (AUD15-T\d{3}) — ([^\n]+)\n\n\*\*Entrega:\*\* (.+?)\n\n\*\*Aceite:\*\* (.+?)(?=\n\n### |\n\n## )', spec, re.M | re.S))
assert len(rows) == len(sections) == 24
backlog = json.loads((ROOT / '.agent/backlog.json').read_text())
assert len(backlog['items']) == 92
assert not any(i['id'].startswith('AUD15-') for i in backlog['items'])
for match in sections:
    ident, title, delivery, acceptance = match.groups()
    _, milestone, priority, size, table_title, owner, deps = rows[ident]
    dependencies = [] if deps == '—' else ['AUD15-T' + d.strip() for d in deps.split(',')]
    line = spec[:match.start()].count('\n') + 1
    backlog['items'].append({
        'id': ident, 'title': title, 'stage': 'BUILD', 'priority': priority,
        'status': 'TODO', 'origin': f'{spec_ref}#L{line}: {title}; current human request implementa todo o conteudo dos planos authorizes reversible local implementation only',
        'origin_refs': [f'{spec_ref}#L{line}', 'docs/reports/evidence/aud15-implementation-20261015/quality-bar.md', '.agent/plans/producao-2026-10-12.md'],
        'dependencies': dependencies, 'dependency_semantics': 'AND',
        'owner': 'Proposed role / not assigned: ' + owner,
        'acceptance_summary': acceptance.strip(), 'delivery_summary': delivery.strip(),
        'evidence_refs': [], 'milestone': milestone, 'size': size, 'mandatory': True,
        'accepted': False, 'specification_ref': spec_ref, 'planning_delivery_title': table_title,
        'common_dod_ref': spec_ref + '#L19-L26',
        'next_action': {'id': ident + ':INSPECT', 'kind': 'INSPECT',
                        'summary': 'Inspect exact contract, dependency evidence and authority before selection; independent preparation is not acceptance',
                        'target': spec_ref,
                        'completion_signal': 'Owner, AND dependencies, authority and evidence procedure established without proxy acceptance'}
    })

scope_ref = 'AUD15-LOCAL-PREPARATION'
action = scope_ref + ':VERIFY-SAFE-PREPARATION'
plan_ref = '.agent/plans/producao-2026-10-12.md'
proof_ref = '.runtime/implementation-aud15-20261015/control/backup-before-adoption/manifest.json'
bar_ref = 'docs/reports/evidence/aud15-implementation-20261015/quality-bar.md'
gate_ref = '.agent/gates/aud15-safe-local-preparation-ready.json'
scope = 'AUD15 safe reversible local preparation and integration control only; no task acceptance, product verification, external runtime or release authority'
backlog['items'].append({
    'id': scope_ref, 'title': 'Prepare and integrate authorized reversible AUD15 local work without accepting task dependencies',
    'stage': 'BUILD', 'priority': 'P0', 'status': 'IN_PROGRESS',
    'origin': 'Current human request implementa todo o conteudo dos planos and exclusive delegated controller ownership; safe local preparation only',
    'dependencies': [], 'owner': 'Exclusive delegated controller writer; Lead integrates functional evidence',
    'accepted': False,
    'acceptance_summary': 'Preserve baseline, adopt exact AUD15 TODO contracts and verify controller/views/integrity; independent review, all task dependencies and product acceptance remain separate',
    'evidence_refs': [proof_ref, bar_ref, plan_ref],
    'next_action': {'id': action, 'kind': 'VERIFY', 'summary': 'Verify safe preparation integrity and reconcile returned local evidence without claiming B01-B17 PASS or task completion',
                    'target': plan_ref, 'completion_signal': 'Real controller/derived/archive checks and hash/prefix proof retained; unresolved B01 audit completion, B07 pre-limiter bound and frontend guards/drafts remain explicit'}
})

plan_path = ROOT / plan_ref
plan = plan_path.read_text()
plan = plan.replace('<!-- engineering-framework: active_action_id=PROD12-LOCAL-CONTROL:VERIFY-LOCAL-SCOPE -->', '<!-- engineering-framework: active_action_id=' + action + ' -->', 1)
plan += '''

## AUD15 controller adoption / recovery checkpoint — 2026-10-15

O novo pedido humano “implementa todo o conteudo dos planos” é a autoridade atual para implementação reversível local e testes sintéticos. A restrição histórica de planejamento em AUD15 permanece preservada como contexto da solicitação anterior. Não há concessão D01–05/07, serviços, DDL real, custos, host, deploy, promoção ou goal manifest. O gate AUD15 de preparação tem identidade/escopo próprios e não reutiliza autoridade PROD12.

Os 24 contratos AUD15-T001…T024 foram adotados no único backlog canônico em TODO, accepted=false, com títulos/entregas/aceites e dependências AND integrais. Os 92 itens de entrada (35 históricos, 56 PROD12 e runner anterior), seus estados, aceites e ações permanecem inalterados. AUD15-LOCAL-PREPARATION é um umbrella separado e sem dependências, dono somente da preparação/integração segura; não satisfaz predecessores nem permite selecionar tarefas dependentes por proxy. Nenhuma tarefa é DONE por este checkpoint.

Baseline e ledgers anteriores foram conferidos contra entry/source e preservados novamente em [backup autenticado](<../../.runtime/implementation-aud15-20261015/control/backup-before-adoption/manifest.json>). Os prefixos dos ledgers, gates antigos, arquivos assinados, goal/bar e identidade do artefato Gauntlet não são reescritos. Derivadas são geradas somente pelo generator original. O owner de estado/active_action desta rodada é o writer exclusivo de controle; builders entregam evidência ao Lead e não escrevem estado.

Próxima ação executável [AUD15-LOCAL-PREPARATION:VERIFY-SAFE-PREPARATION]: conferir hashes/prefixos e contratos, rodar os validadores reais de controle/arquivo/derivadas e integrar evidências retornadas com crítica independente. Permanecem lacunas B01 (audit completion tardio), B07 (limite pré-limiter) e frontend (same-session draft/guards) em correção; NÃO há B01–17 PASS. B17 e as obrigações externas PROD12 mantêm NOT_RUN/BLOCKED_EXTERNAL e autoridade própria. G6/canary não é usado como prova circular nem tem dependências alteradas. Produto PARTIAL / NO-GO; sem autoaceite.

Recuperação: ler estado/backlog/ledgers/plano e comparar o [backup](<../../.runtime/implementation-aud15-20261015/control/backup-before-adoption/>) antes de qualquer retry; não restaurar o checkout inteiro, não normalizar eventos antigos e não apagar falhas. Evidências desta transação ficam em [control](<../../.runtime/implementation-aud15-20261015/control/>). O checklist PROD12 histórico acima permanece histórico; o ponteiro de ação atual é o comentário inicial e o estado canônico.
'''
plan_path.write_text(plan)
dump(ROOT / '.agent/backlog.json', backlog)

refs = [spec_ref, bar_ref, plan_ref, proof_ref]
criteria = []
for ident, desc in [
    ('IR-001', 'Current human instruction and exact AUD15 contracts define only reversible local preparation with disjoint ownership'),
    ('IR-002', 'Baseline bytes and all 24 contracts are inspected; AND dependencies and all prior tasks remain unaccepted and unchanged'),
    ('IR-003', 'Guarded backup, original generators and executable validation/recovery procedures preserve history and fail closed')
]:
    criteria.append({'id': ident, 'description': desc, 'required': True, 'status': 'PASS',
                     'evidence_refs': refs, 'confidence': 'HIGH',
                     'limitations': 'Preparation readiness only, not implementation correctness. B01/B07/frontend gaps and B17 remain open; no task dependency or acceptance satisfied.'})
gate = {'record_id': 'GATE-AUD15-SAFE-LOCAL-PREPARATION-READY-001', 'timestamp': ts(),
        'gate_id': 'IMPLEMENTATION_READY', 'scope': scope, 'scope_ref': scope_ref, 'version': 1,
        'criteria': criteria, 'evidence': refs, 'confidence': 'HIGH', 'gaps': [], 'conditions': [],
        'authority': {'required': False, 'state': 'NOT_REQUIRED', 'actor': 'Exclusive delegated controller writer; current human request only',
                      'scope': scope, 'decision': 'Current explicit request authorizes reversible local preparation; no cross-scope approval reused or external authority inferred',
                      'evidence_ref': plan_ref, 'expires_or_revalidates': 'Any material scope, contract or ownership change; external effects require separate authority'},
        'residual_risk': 'MEDIUM', 'decision': 'PASS', 'next_action': 'Verify protected history, original derived views and controller; integrate local evidence without task acceptance',
        'revalidation_triggers': ['Protected baseline mismatch', 'Scope expands beyond safe reversible local work', 'Ownership collision or material budget/UX decision'], 'supersedes': None}
assert not (ROOT / gate_ref).exists()
dump(ROOT / gate_ref, gate)
fp = hashlib.sha256(json.dumps(gate, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
events = []
def event(n, typ, ident, action_text, result='PASS', **extra):
    events.append({'event_id': ident, 'timestamp': ts(n), 'type': typ, 'task': scope_ref,
                   'action': action_text, 'result': result, 'verification': proof_ref,
                   'decision': 'Safe preparation only; preserve all 92 previous items and AND dependencies, no DONE/acceptance or D01-05/07 authority',
                   'next_state': 'IN_PROGRESS', 'active_action_id': action, **extra})
event(1, 'GATE_PASSED', 'EVT-AUD15-SAFE-PREPARATION-GATE-20261015', 'Bind new narrow safe preparation gate; not product VERIFIED or GO',
      gate_ref=gate_ref, gate_record_id=gate['record_id'], gate_decision='PASS', gate_fingerprint=fp)
event(2, 'DECISION', 'EVT-AUD15-PREPARATION-READY-20261015', 'Select dependency-free preparation umbrella', status_from='TODO', status_to='READY', next_state='READY')
event(3, 'START', 'EVT-AUD15-PREPARATION-START-20261015', 'Start safe preparation under exclusive controller ownership', status_from='READY', status_to='IN_PROGRESS')
event(4, 'RECOVERY', 'EVT-AUD15-CONTROL-ADOPTED-20261015', 'Adopt 24 exact TODO AUD15 contracts and reconcile current human local authority; original ledger prefixes retained', result='PARTIAL')
with (ROOT / '.agent/execution-log.jsonl').open('a') as stream:
    for item in events:
        stream.write(json.dumps(item, ensure_ascii=False, separators=(',', ':')) + '\n')
state = json.loads((ROOT / '.agent/state.json').read_text())
state.update(active_task=scope_ref, active_action_id=action, last_gate_record=gate_ref,
             last_event_id=events[-1]['event_id'], state_revision=state['state_revision'] + 1,
             verification_state='PARTIAL', active_activity='VERIFY', updated_at=ts(5),
             repository_state='AUD15 safe local preparation only: 24 TODO/unaccepted contracts adopted; all 92 entry items and prior ledger prefixes preserved. Dirty checkout 48e383c25ca4af32aa7ffe7e2367360ca9742c58. Structural verification pending; B01 audit completion, B07 pre-limiter bounds and frontend same-session draft/guards remain open. Product NO-GO.')
state['instruction_scope_refs'] = list(dict.fromkeys(state['instruction_scope_refs'] + [spec_ref, bar_ref]))
state['blocked_by'] += ['AUD15 local B01 audit completion tardio, B07 limite pre-limiter and frontend same-session draft/guards remain in correction; no B01-B17 PASS or task DONE', 'AUD15 external B17 retains PROD12 authority/evidence obligations; local preparation is not product verification or GO']
dump(ROOT / '.agent/state.json', state)
print('Adopted 24 TODO contracts, separate preparation umbrella and new narrow gate; 92 prior items untouched')
