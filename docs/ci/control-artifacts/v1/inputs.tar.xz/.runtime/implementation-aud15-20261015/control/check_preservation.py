from pathlib import Path
import hashlib,json,re
root=Path.cwd();out=root/'.runtime/implementation-aud15-20261015/control';backup=out/'backup-before-adoption';entry=root/'.runtime/implementation-aud15-20261015/entry/source'
old=json.loads((backup/'.agent/backlog.json').read_text());new=json.loads((root/'.agent/backlog.json').read_text())
assert len(old['items'])==92 and new['items'][:92]==old['items']
assert json.loads((entry/'.agent/backlog.json').read_text())==old
prefixes={}
for rel in ['.agent/execution-log.jsonl','.agent/verification.jsonl']:
 original=(backup/rel).read_bytes(); current=(root/rel).read_bytes()
 assert current.startswith(original) and original==(entry/rel).read_bytes()
 prefixes[rel]={'bytes':len(original),'records':len(original.splitlines()),'sha256':hashlib.sha256(original).hexdigest(),'prefix_exact':True,'current_records':len(current.splitlines())}
manifest=json.loads((backup/'manifest.json').read_text())['files']; mutable={'.agent/backlog.json','.agent/state.json','.agent/execution-log.jsonl','.agent/verification.jsonl','.agent/plans/producao-2026-10-12.md'}
protected={}
for rel,meta in manifest.items():
 if rel not in mutable:
  actual=hashlib.sha256((root/rel).read_bytes()).hexdigest();assert actual==meta['sha256'],rel;protected[rel]=actual
spec=(root/'docs/backlog-auditoria-2026-10-15.md').read_text(); rows={}
for line in spec.splitlines():
 if line.startswith('| AUD15-T'):
  row=[x.strip() for x in line.strip('|').split('|')];rows[row[0]]=row
sections=re.findall(r'^### (AUD15-T\d{3}) — ([^\n]+)\n\n\*\*Entrega:\*\* (.+?)\n\n\*\*Aceite:\*\* (.+?)(?=\n\n### |\n\n## )',spec,re.M|re.S)
items={i['id']:i for i in new['items']};checked=[]
for ident,title,delivery,acceptance in sections:
 i=items[ident];row=rows[ident];deps=[] if row[6]=='—' else ['AUD15-T'+x.strip() for x in row[6].split(',')]
 assert (i['title'],i['delivery_summary'],i['acceptance_summary'])==(title,delivery.strip(),acceptance.strip()),ident
 assert i['dependencies']==deps and i['dependency_semantics']=='AND',ident
 assert i['status']=='TODO' and i['accepted'] is False and not i['evidence_refs'],ident
 assert i['origin_refs'] and i['specification_ref']=='docs/backlog-auditoria-2026-10-15.md'
 checked.append(ident)
assert len(checked)==24 and len(items)==117
visiting=set();visited=set()
def walk(ident):
 assert ident not in visiting,ident
 if ident in visited:return
 visiting.add(ident)
 for dep in items[ident]['dependencies']: assert dep in items;walk(dep)
 visiting.remove(ident);visited.add(ident)
for ident in items:walk(ident)
state=json.loads((root/'.agent/state.json').read_text());gate=json.loads((root/state['last_gate_record']).read_text());events=[json.loads(l) for l in (root/'.agent/execution-log.jsonl').read_text().splitlines()]
fp=hashlib.sha256(json.dumps(gate,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert gate['scope_ref']==state['active_task']=='AUD15-LOCAL-PREPARATION'
assert len([e for e in events if e.get('gate_fingerprint')==fp])==1
assert state['last_event_id']==events[-1]['event_id']
report={'result':'PASS','scope':'Structural preservation and adoption only; no task acceptance or product verification','previous_items_semantically_exact':92,'previous_prod12_exact':56,'adopted_todo_unaccepted_exact_contracts':checked,'dependency_graph_acyclic':True,'ledger_prefixes':prefixes,'protected_sha256':protected,'gate_fingerprint':fp,'current_items':117,'state_revision':state['state_revision']}
(out/'preservation-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS: 92 previous items exact; 24 exact TODO unaccepted AUD15 contracts; protected hashes/prefixes/gate/acyclic dependencies verified')
